package com.tutsplus.zoo.fragments;

import android.support.v4.app.Fragment;

/**
 * Created by paulruiz on 4/8/15.
 */
public class GalleryFragment extends Fragment {

    public static GalleryFragment getInstance() {
        GalleryFragment fragment = new GalleryFragment();

        return fragment;
    }

}
