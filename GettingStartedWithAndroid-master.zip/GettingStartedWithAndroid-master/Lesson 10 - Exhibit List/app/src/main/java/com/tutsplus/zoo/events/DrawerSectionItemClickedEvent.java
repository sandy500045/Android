package com.tutsplus.zoo.events;

/**
 * Created by paulruiz on 4/8/15.
 */
public class DrawerSectionItemClickedEvent {

    public String section;

    public DrawerSectionItemClickedEvent( String section ) {
        this.section = section;
    }
}
