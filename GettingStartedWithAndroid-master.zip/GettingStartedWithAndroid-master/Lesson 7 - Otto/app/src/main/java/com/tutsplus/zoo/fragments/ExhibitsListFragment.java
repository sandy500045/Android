package com.tutsplus.zoo.fragments;

import android.support.v4.app.ListFragment;

/**
 * Created by paulruiz on 4/8/15.
 */
public class ExhibitsListFragment extends ListFragment {

    public static ExhibitsListFragment getInstance() {
        ExhibitsListFragment fragment = new ExhibitsListFragment();
        return fragment;
    }
}
